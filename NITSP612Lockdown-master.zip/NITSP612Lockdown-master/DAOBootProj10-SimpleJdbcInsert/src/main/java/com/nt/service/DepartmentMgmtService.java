package com.nt.service;

import com.nt.dto.DepartmentDTO;

public interface DepartmentMgmtService {
	
	public String registerDepartment(DepartmentDTO dto);

}
