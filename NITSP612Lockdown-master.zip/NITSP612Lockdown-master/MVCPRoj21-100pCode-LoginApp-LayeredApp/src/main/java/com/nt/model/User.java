package com.nt.model;

import lombok.Data;
@Data
public class User  {
   private String uname;
   private String pwd;
  
}
