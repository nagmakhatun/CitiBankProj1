package com.nt.bo;

import lombok.Data;

@Data
public class UserBO {
   private String uname;
   private String pwd;
   
}
