package com.nt.service;

public interface LoginMgmtService {
	
	public String signIn(String username,String password);
	

}
