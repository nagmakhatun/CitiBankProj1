package com.nt.errors;

public class InternalProblemException extends RuntimeException {
	
	public InternalProblemException(String msg) {
		super(msg);
	}

}
