package com.nt.dao;

public interface WithdrawDAO {
    public  int withdraw(long acno,float amt);
}
